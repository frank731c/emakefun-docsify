/***********************************************************************
 *
 *
 * emakefun Tech firmware
 *
 * Copyright (C) 2015-2020
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, in version 3.
 * learn more you can see <http://www.gnu.org/licenses/>.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.
 *
 *
 * [Title]     stepper motor  .
 * [Diagram]
 *         Arduino Uno PIN 5   ===================  Stepper motor A
 *         Arduino Uno PIN 6   ===================  Stepper motor B
 *         Arduino Uno PIN 9  ===================   Stepper motor C
 *         Arduino Uno PIN 10  ===================  Stepper motor D
*/

#include "28BYJ48_Stepper.h"
// half phase step mode28B
#define STEPS 64  
Stepper stepper(STEPS, 5, 6, 9, 10);        // arduino uno pin define
//Stepper stepper(STEPS, 17, 16, 15, 14);   // ESP32-IOT-BOARD pin define

// the previous reading from the analog input
int previous = 0;

void setup() {
Serial.begin(115200);
  // set the speed of the motor to 200 RPMs
  stepper.setSpeed(500);
}

void loop() {
  stepper.step(4096);
  delay(2000);
  stepper.step(-4096);
  delay(2000);  
}
