const uint8_t kPinA = 5;
const uint8_t kPinB = 6;
const uint8_t kPinC = 9;
const uint8_t kPinD = 10;

void setup() {
    pinMode(kPinA, OUTPUT);  // 设置电机端口为输出模式
    pinMode(kPinB, OUTPUT);
    pinMode(kPinC, OUTPUT);  
    pinMode(kPinD, OUTPUT);  
}

void loop() {
    analogWrite(kPinA, 255);  // 设置A端口为高电平
    analogWrite(kPinB, 0);    // 设置B端口为低电平
    analogWrite(kPinC, 255);  // 设置C端口为高电平
    analogWrite(kPinD, 0);    // 设置D端口为低电平
    delay(2000);              // 2s之后电机反转
    analogWrite(kPinA, 0);    // 设置A端口为低电平
    analogWrite(kPinB, 255);  // 设置B端口为高电平
    analogWrite(kPinC, 0);    // 设置C端口为低电平
    analogWrite(kPinD, 255);  // 设置D端口为高电平
    delay(2000);              // 电机反转2s然后正转
}