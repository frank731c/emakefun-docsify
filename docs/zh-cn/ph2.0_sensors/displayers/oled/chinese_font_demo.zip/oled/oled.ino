#include "em_oled.h"

EM_OLED u8g2(U8G2_R0, U8X8_PIN_NONE);

void setup() {
  Serial.begin(115200);
  u8g2.begin();
}

void loop() {
  u8g2.firstPage();
  do
  {    
    u8g2.ShowFont(0, 0, "EMAKEFUN易创空间www.emakefun.com");
  }while(u8g2.nextPage());
}
