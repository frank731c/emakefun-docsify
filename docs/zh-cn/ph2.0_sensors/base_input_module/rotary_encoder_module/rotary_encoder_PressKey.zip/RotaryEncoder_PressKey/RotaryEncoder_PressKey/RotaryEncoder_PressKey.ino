/* Encoder Library - Basic Example
 * http://www.pjrc.com/teensy/td_libs_Encoder.html
 *
 * This example code is in the public domain.
 */

#include <Encoder.h>

// Change these two numbers to the pins connected to your encoder.
//   Best Performance: both pins have interrupt capability
//   Good Performance: only the first pin has interrupt capability
//   Low Performance:  neither pin has interrupt capability
Encoder myEnc(5, 6);
//   avoid using pins with LEDs attached
#define KEY 7

void setup() {
  Serial.begin(9600);
  Serial.println("Basic Encoder Test:");
  pinMode(KEY, INPUT_PULLUP);  // KEY引脚配置为上拉输入
}

long oldPosition = -999;

void loop() {
  long newPosition = myEnc.read();
  if (newPosition != oldPosition) {
    oldPosition = newPosition;
    Serial.println(newPosition);
  }

  // KEY按下清零
  if (digitalRead(KEY) == LOW) {
    myEnc.write(0);   // 编码器计数清零
    oldPosition = 0;  // 同步旧位置
    Serial.println("Key pressed, encoder reset to 0");
    delay(200);                       // 消抖延时
    while (digitalRead(KEY) == LOW);  // 等待按键释放
  }
}
