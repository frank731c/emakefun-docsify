# 麦克风功放回环测试 (es8311_test)

## 功能说明

测试 ES8311 音频编解码器，实现**麦克风输入 → 功放输出**的实时回环。对着板载麦克风说话，声音会从外接喇叭实时播放出来。

## 依赖库

无外部依赖库，使用 ESP-IDF 底层 I2S 驱动和板载 ES8311 驱动代码。

## 前置条件

- Arduino IDE 开发板选择 **ESP32S3 Dev Module**
- PSRAM 设置为 **OPI PSRAM**

## 使用方法

1. **外接喇叭**到开发板的喇叭接口
2. 编译并上传程序
3. 对着板载麦克风说话

## 预期结果

- 串口输出初始化日志，无报错信息
- 对着麦克风说话时，**喇叭实时播放麦克风采集的声音**
- 音量约为 70%（代码中设置）

## 常见问题

| 问题 | 解决方案 |
|------|---------|
| 编译报错 `This example only supports ESP32S3-Dev board` | 开发板选择 ESP32S3 Dev Module |
| 编译报错 `requires PSRAM to OPI PSRAM` | PSRAM 设置为 OPI PSRAM |
| 喇叭无声音 | 检查喇叭是否接好，确认麦克风正常工作 |
| 有杂音 | 检查接线是否牢固，远离干扰源 |

## 硬件说明

| 组件 | 引脚 |
|------|------|
| I2S MCLK | IO11 |
| I2S SCLK (BCLK) | IO10 |
| I2S LRCK (WS) | IO8 |
| I2S DSDIN (DOUT) | IO7 |
| I2S ASDOUT (DIN) | IO9 |
| I2C SCL | IO12 |
| I2C SDA | IO13 |
