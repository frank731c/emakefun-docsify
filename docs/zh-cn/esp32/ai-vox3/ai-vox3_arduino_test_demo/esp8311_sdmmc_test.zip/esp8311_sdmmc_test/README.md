# SD 卡 MP3 播放测试 (esp8311_sdmmc_test)

## 功能说明

从 SD 卡读取 MP3 文件并通过 ES8311 音频编解码器播放。程序会播放 SD 卡根目录下的 `/test.mp3` 文件。

## 依赖库

| 库名 | 安装方式 |
|------|---------|
| ESP32-audioI2S | Arduino IDE → 工具 → 管理库 → 搜索 `ESP32-audioI2S` 安装 |

## 前置条件

- Arduino IDE 开发板选择 **ESP32S3 Dev Module**
- PSRAM 设置为 **OPI PSRAM**
- SD 卡格式为 **FAT32**
- SD 卡根目录下放置一个名为 **`test.mp3`** 的音频文件

## 使用方法

1. 将 MP3 文件重命名为 `test.mp3`，复制到 SD 卡**根目录**
2. 将 SD 卡插入开发板的 TF 卡槽
3. **外接喇叭**到开发板的喇叭接口
4. 安装依赖库 `ESP32-audioI2S`
5. 编译并上传程序
6. 打开串口监视器，波特率设为 **115200**

## 预期结果

串口输出示例：

```
----------------------------------
ESP32 Chip: ESP32-S3
Arduino Version: x.x.x
ESP-IDF Version: x.x.x
----------------------------------

info        connecttoFS: /test.mp3
info        MP3Decoder: ...
info        SampleRate: 44100
info        Channels: 2
info        BitsPerSample: 16
info        Bitrate: 128
```

**喇叭播放 SD 卡中的 MP3 音乐。**

## 常见问题

| 问题 | 解决方案 |
|------|---------|
| 串口输出 `Card Mount Failed` | 检查 SD 卡是否插好，格式是否为 FAT32 |
| 编译报错 `requires PSRAM to OPI PSRAM` | PSRAM 设置为 OPI PSRAM |
| 喇叭无声音 | 检查喇叭连接，确认 MP3 文件存在于 SD 卡根目录 |
| 播放有杂音/卡顿 | 检查 MP3 文件是否损坏，尝试更换音频文件 |

## 硬件说明

| 组件 | 引脚 |
|------|------|
| SD CMD | IO38 |
| SD CLK | IO39 |
| SD DAT0 | IO40 |
| I2S DOUT | IO7 |
| I2S BCLK | IO10 |
| I2S MCLK | IO11 |
| I2S LRC | IO8 |
| I2C SCL | IO12 |
| I2C SDA | IO13 |
| PA Enable | IO53 |
