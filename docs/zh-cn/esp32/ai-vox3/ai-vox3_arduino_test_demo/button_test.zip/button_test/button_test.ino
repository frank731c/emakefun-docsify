#define BUTTONA_PIN 46
#define BUTTONB_PIN 45
#define KEY_DELAY 20

void setup() {
  Serial.begin(115200);
  delay(10);
  pinMode(BUTTONA_PIN,INPUT);
  pinMode(BUTTONA_PIN,INPUT);
  Serial.println("Button Test Start");
}

void loop() {
  if (digitalRead(BUTTONA_PIN) == LOW)
  {
    delay(KEY_DELAY);       
    if (digitalRead(BUTTONA_PIN) == LOW)
    {
      Serial.println("Button A press");
      while(digitalRead(BUTTONA_PIN) == LOW);
      delay(KEY_DELAY);
    }
  }

  if (digitalRead(BUTTONB_PIN) == LOW)
  {
    delay(KEY_DELAY);
    if (digitalRead(BUTTONB_PIN) == LOW)
    {
      Serial.println("Button B press");
      while(digitalRead(BUTTONB_PIN) == LOW);
      delay(KEY_DELAY);
    }
  }
}
